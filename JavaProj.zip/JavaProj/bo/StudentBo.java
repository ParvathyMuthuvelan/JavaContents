package com.training.bo;

import java.util.List;

import com.training.bean.Student;
import com.training.dao.StudentDao;
import com.training.dao.StudentDaoImpl;

public class StudentBo {

	public void create(Student student) {
		StudentDao studentDao=new StudentDaoImpl();
		studentDao.create(student);
		
	}

	public List<Student> read(int total) {
		StudentDao studentDao=new StudentDaoImpl();
		List<Student> studentList=studentDao.read(total);
		return studentList;
	}
	
	public void update(int regno) {
		StudentDao studentDao=new StudentDaoImpl();
		studentDao.update(regno);
		
	}

	public void delete(int regno) {
		StudentDao studentDao=new StudentDaoImpl();
		studentDao.delete(regno);
		
	}

}
