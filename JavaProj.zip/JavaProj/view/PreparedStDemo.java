package com.training.view;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.training.bean.Student;
import com.training.bo.StudentBo;

public class PreparedStDemo {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int regno, m1, m2, m3, total;
		String sname, choice;
		int ch;
		StudentBo studentBo = new StudentBo();
		List<Student> list = new ArrayList<>();
		do {
			System.out.println("CRUD Application");
			System.out.println("1.Create \n 2.Read \n 3.Update \n4.Delete");
			System.out.println("Enter choice");
			ch = scanner.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter student regno,name and marks in 3 subjects");
				regno = scanner.nextInt();
				sname = scanner.next();
				m1 = scanner.nextInt();
				m2 = scanner.nextInt();
				m3 = scanner.nextInt();
				// create(regno,name,m1,m2,m3)
				Student student = new Student();
				student.setRegno(regno);
				student.setName(sname);
				student.setWebScore(m1);
				student.setSqlScore(m2);
				student.setJavaScore(m3);

				studentBo.create(student);

				break;
			case 2:
				System.out.println("Enter total");
				total = scanner.nextInt();

				list = studentBo.read(total);
				list.forEach(s -> System.out.println(s));
//				for(Student s:list)
//				{
//					System.out.println(s);
//				}

				break;

			case 3:
				System.out.println("Enter regno to update total");
				regno = scanner.nextInt();

				studentBo.update(regno);

				break;
			case 4:
				System.out.println("Enter regno to delete");
				regno = scanner.nextInt();

				studentBo.delete(regno);

				break;
			default:
				System.out.println("Invalid choice");
			}

			System.out.println("want to continue");
			choice = scanner.next();
		} while (choice.equals("yes"));

	}
}
