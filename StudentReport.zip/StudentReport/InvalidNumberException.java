package com.training.jdbc;

public class InvalidNumberException extends Exception {

	public InvalidNumberException(String s) {
		super(s);
	}
}
